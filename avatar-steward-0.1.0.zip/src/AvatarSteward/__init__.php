<?php
/**
 * Silence is golden.
 *
 * @package AvatarSteward
 */

// Silence is golden.
