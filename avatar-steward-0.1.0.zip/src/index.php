<?php
/**
 * Silence is golden.
 *
 * @package AvatarSteward
 */

declare(strict_types=1);

exit;
